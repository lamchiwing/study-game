# apps/backend/auth/__init__.py
from .auth_routes import router as auth_router

__all__ = ["auth_router"]


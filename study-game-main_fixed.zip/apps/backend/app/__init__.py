"""
app package

Keep this file minimal.
Do NOT put runtime logic here.
"""

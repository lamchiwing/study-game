# apps/backend/app/routers/__init__.py
# keep empty
